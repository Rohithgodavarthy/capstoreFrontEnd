import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{Routes,RouterModule} from '@angular/router';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListComponent } from './list.component';
import { HomeComponent } from './home.component';

const appRoutes : Routes = [
  // {path:'', component:AppComponent},
  {path:'', redirectTo:"home", pathMatch:"full"},
  {path:'home',component:HomeComponent},
  {path:'seeproducts',component:ListComponent}

];
@NgModule({
  declarations: [
    AppComponent,ListComponent,HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,RouterModule.forRoot(appRoutes),
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
